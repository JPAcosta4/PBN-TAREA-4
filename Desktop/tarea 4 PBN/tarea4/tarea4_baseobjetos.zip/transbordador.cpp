#include <iostream>
#include "transbordador.h"

using namespace std;

// constructor
transbordador::transbordador(string n, string p, int c, int f, int l){
	nombre=n;
	puertoActual=p;
	capacidad=c;
	filas=f;
	largo=l; 
	fila0= list<vehiculo>(); 
	fila1= list<vehiculo>(); 
	fila2= list<vehiculo>(); 
	fila3= list<vehiculo>(); 
	fila4= list<vehiculo>(); 
	if (filas>5){
		filas = 5;
	}

}
// constructor por defecto
transbordador::transbordador(){
	nombre="N/A";
	puertoActual="N/A";
	capacidad=0;
	filas=0;
	largo=0;
}

// destructor
transbordador::~transbordador(){
}

bool transbordador::pushVehiculo(int fila, vehiculo v){
	if (fila == 0){	
		fila0.push_back(v);
	} 

	else if (fila ==1){
		fila1.push_back(v);
	}

	else if (fila ==2){
		fila2.push_back(v);
	}

	else if (fila ==3){
		fila3.push_back(v);
	}

	else if (fila ==4){
		fila4.push_back(v);
	}
	return true; 
} 

void transbordador::popVehiculo(int fila){
	if (fila == 0){
		fila0.pop_back(); 
	}

	else if (fila ==1){
		fila1.pop_back();
	}

	else if (fila ==2){
		fila2.pop_back();
	}

	else if (fila ==3){
		fila3.pop_back();
	}

	else if (fila ==4){
		fila4.pop_back();
	}

}


int transbordador::getEspacioLibre(int fila){
	int valores = 0; 
	if (fila == 0){
		list<vehiculo>::iterator itr; 
		itr = fila0.begin(); 
		for (itr; itr!= fila0.end(); itr++){
				valores += itr->largo += 15; 
		}
		return (largo-valores); 
	}
	
	else if (fila == 1){
		list<vehiculo>::iterator itr; 
		itr = fila1.begin(); 
		for (itr; itr!= fila1.end(); itr++){
				valores += itr->largo += 15; 
		}
		return (largo-valores); 
	}

	else if (fila == 2){
		list<vehiculo>::iterator itr; 
		itr = fila2.begin(); 
		for (itr; itr!= fila2.end(); itr++){
				valores += itr->largo += 15; 
		}
		return (largo-valores); 
	}

	else if (fila == 3){
		list<vehiculo>::iterator itr; 
		itr = fila3.begin(); 
		for (itr; itr!= fila3.end(); itr++){
				valores += itr->largo += 15; 
		}
		return (largo-valores); 
	}

	else if (fila == 4){
		list<vehiculo>::iterator itr; 
		itr = fila4.begin(); 
		for (itr; itr!= fila4.end(); itr++){
				valores += itr->largo += 15; 
		}
		return (largo-valores); 
	}	
	return 0; 
  //Recibe como parámetro el int fila 
}

int transbordador::getLargoFila(int fila){
	if (fila == 0){
		return fila0.size(); 
	}
	else if (fila == 1){
		return fila1.size(); 
	}

	else if (fila == 2){
		return fila2.size(); 
	}

	else if (fila == 3){
		return fila3.size(); 
	}

	else if (fila == 4){
		return fila4.size(); 
	}
	return 0; 
}

int transbordador::getPesoLibre(){
	int suma_peso = 0;  
	list<vehiculo>::iterator itr; 
	itr = fila0.begin();  
	if (fila0.size() >0){
		for (itr; itr!= fila0.end(); itr++){
			suma_peso += itr->peso; 
		}
	}
	if (fila1.size()>0){
		itr = fila1.begin();  
		for (itr; itr!= fila1.end(); itr++){
			suma_peso += itr->peso; 
		}
	}

	if (fila2.size()>0){
		itr = fila2.begin();  
		for (itr; itr!= fila2.end(); itr++){
			suma_peso += itr->peso; 
		}
	}

	if (fila3.size()>0){
		itr = fila3.begin();  
		for (itr; itr!= fila3.end(); itr++){
			suma_peso += itr->peso; 
		}
	}

	if (fila4.size()>0){
		itr = fila4.begin();  
		for (itr; itr!= fila4.end(); itr++){
			suma_peso += itr->peso; 
		}
	}

	return (capacidad-suma_peso); 
} 
		

bool transbordador::getTipo(){
	return true; 
}	


