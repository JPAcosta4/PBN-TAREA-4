#ifndef _GAT
#define _GAT

using namespace std;

enum tipo {
	car, // Le tuve que poner car porque auto lo define como un comando personalizado. 
	camion, 
	bus, 
	ambulancia, 
	indefinido
}; 

class vehiculo {
	private:
	public:
		tipo vehiculo_tipo; 
		vehiculo(); // Constructor por defecto
		vehiculo(string m, int l, int p, tipo t);
		~vehiculo();	// destructor
		string marcaModelo;
		int largo; 
		int peso;
		// falta hacer el enum, de tipo de vehiculo. 
		int getLargo(); 
		int getPeso(); 
		tipo getTipo(); 
		//funcion getTipo() 
};

#endif
