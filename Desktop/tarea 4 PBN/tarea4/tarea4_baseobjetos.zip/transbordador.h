#include <list> 
#include "vehiculo.h"


using namespace std;


class transbordador {
	private:
	public:

		transbordador();		// Constructor por defecto
		transbordador(string n, string p, int c, int f, int l);
		~transbordador();	// destructor
		string nombre;
		string puertoActual;
		int capacidad;  
		int filas; 
		int largo; 
		list <vehiculo> fila0; 
		list <vehiculo> fila1; 
		list <vehiculo> fila2; 
		list <vehiculo> fila3; 
		list <vehiculo> fila4; 
		bool pushVehiculo(int,vehiculo); //Recibe como parámetros el int fila, vehiculo v, ver como agregarlo.  
		void popVehiculo(int); //Recibe como parámetro el int de fila para eliminar ese vehiculo en específico.  
		int getEspacioLibre(int); //Recibe como parámetro el int fila 
		int getLargoFila(int); // Calcular cuantos vehículos en la fila. 
		int getPesoLibre(); 
		bool getTipo();  
		
};

