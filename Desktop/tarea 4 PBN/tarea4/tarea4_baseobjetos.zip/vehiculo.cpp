#include <iostream>
#include "vehiculo.h"

using namespace std;

// constructor
vehiculo::vehiculo(string m, int l, int p, tipo t){
	marcaModelo=m;
	largo=l;
	peso=p;
	vehiculo_tipo = t; 
}
// constructor por defecto
vehiculo::vehiculo(){
	marcaModelo="N/A";
	largo = 0; 
	peso = 0; 
	vehiculo_tipo = indefinido; 
}

// destructor
vehiculo::~vehiculo(){
}

int vehiculo::getLargo(){
	return largo; 
}


int vehiculo::getPeso(){ 
	return peso;
} 
	
tipo vehiculo::getTipo(){
	return vehiculo_tipo;
} 


