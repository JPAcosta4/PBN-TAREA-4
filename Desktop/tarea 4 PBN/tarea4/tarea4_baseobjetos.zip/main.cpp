#include <iostream>
#include "vehiculo.h"
#include "transbordador.h"
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <list> 

using namespace std;

int main(){

	vehiculo v1("Mercedes", 152, 500, car);  
	transbordador t1("Mikaela", "Bolivia",10000, 120, 5000); 
	t1.pushVehiculo(0,v1); 
	t1.pushVehiculo(0,v1);
	t1.pushVehiculo(1,v1);
	t1.popVehiculo(0); 
	t1.popVehiculo(1); 

	cout << t1.getEspacioLibre(0) << endl; 
	cout << t1.getPesoLibre() << endl; 

	return 0;
}
